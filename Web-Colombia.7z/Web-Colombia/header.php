<div class="FixedTopContainer FixedTopContainerBlack" id="FixedTopContainer">
                    <div class="fixed-top" >
                          <div class="top-bar d-flex contact-bar" id="TopBar">
                               <div class="numbers d-flex contact-home">
                                   <div class="solv-mobile">
                                       <img src="assets/img/solventa-violeta.svg" alt="solventa">
                                   </div>

                                    <button id="BtnMenu">
                                    <div class="Menu-Icon Menu-Icon-faqs" id="AnimatedIcon">
                                        <div class="Line1"></div>
                                        <div class="Line2"></div>
                                        <div class="Line3"></div>
                                    </div>
                                    </button>                                 

                                   <div class="d-flex box-contact">
                                       <img class="phone-icon" src="assets/img/phone-gris.svg" alt="icono telefono">
                                       <a href="" class="phone-number">(1) 639 8384</a>
                                   </div>                
                               </div>
                               <div class="flags">
                                   <a href="http://www.solventa.co"><img src="assets/img/colombia.png" alt="bandera colombia"></a>
                                   <a href="https://www.solventa.com.ar/"><img class="arg-flag" src="assets/img/argentina.png" alt="bandera argentina"></a> 
                               </div>
                          </div>
                        
                          <div class="menu d-flex fixed-bar" id="menu">
                                <div class="d-flex">
                                      <div class="d-flex top-bar-menu">
                                        <div class="solventa-box" >
                                            <img class="solventa solv-desktop" src="assets/img/solventa-violeta.svg" id="SolvDesktop" alt="SOLVENTA">
                                        </div>
                                      </div>
                                      <div class="menu-list menu-list-faqs d-flex">
                                          <ul class="d-flex" id="ContainerMenu">
                                              <li><a class="menu-lnks BtnLinksMenu" id="inicio" href="/">Inicio</a></li>
                                              <li><a class="menu-lnks BtnLinksMenu" href="preguntas-frecuentes">Preguntas Frecuentes</a></li>
                                              <!--li><a class="menu-lnks BtnLinksMenu" href="" id="">Blog</a></li-->
                                              <li><a class="menu-lnks BtnLinksMenu" href="centro-de-ayuda">Ayuda</a></li>
                                          </ul>
                                          <div class="box-mi-cuenta">
                                               <button class="white-border-btn-scroll" id="BtnCuenta">Mi Cuenta</button>
                                               <!--button class="green-btn">PEDIR PRÉSTAMO</button-->
                                          </div>
                                      </div>
                                      <div class="top-bar d-flex top-bar-mobile">
                                            <div class="numbers d-flex contact-home">
                                                <div class="d-flex box-contact box-contact-mobile">
                                                    <img class="phone-icon" src="assets/img/phone-gris.svg" alt="icono telefono">
                                                    <span class="num-tel">000 0000 0000</span>
                                                </div>           
                                            </div>
                                            <div class="flags flags-mobile">
                                                <a href="http://www.solventa.co"><img src="assets/img/colombia.png" alt="bandera colombia"></a>
                                                <a href="http://www.solventa.com.ar"><img class="arg-flag" src="assets/img/argentina.png" alt="bandera argentina"></a> 
                                            </div>
                                       </div>
                                </div>
                          </div>
                    </div>
        </div>