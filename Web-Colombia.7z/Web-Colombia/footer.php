<footer class="d-flex" >
                <div class="footer-box footer-box-one">
                    <img class="solventa" src="assets/img/solventa-white.svg" alt="solventa imagen">
                    <p class="p-footer" style="margin-top: 1em">Somos una Fintech que nació con el fin de ofrecer Préstamos Personales 100% Online de una manera rápida, segura y simple.</p>
            
                    <!--div class="aliados">
                        <p>Nuestros aliados</p>
                        <img class="colombia-fintech" src="assets/img/colombia-fintech.png" alt="">
                        <img class="datacredito" src="assets/img/datacredito.png" alt="">
                        <img class="liberty" src="assets/img/liberty.png" alt="">
                    </div-->
            
                </div>
                <div class="footer-box footer-box footer-box-dos">
            
                    <div>
                        <p class="title-footer">Préstamo</p>
                        <div class="links-footer">
                            <a href="">Mi cuenta</a>
                            <a href="">Pedir Préstamo</a>
                        </div>
                    </div> 
                    <div class="ayuda">
                            <p class="title-footer">Ayuda</p>
                            <div class="links-footer">
                                <a href="">Contacto</a>
                                <a href="">Preguntas Frecuentes</a>
                                <a href="">Blog</a>
                            </div>
                    </div>        
                    <div>
                        <p class="title-footer">Servicio</p>
                        <div class="links-footer">
                            <a href="">Inicio</a>
                            <a href="">Testimonios</a>
                            <a id="Tasas" href="">Tasa e Intereses</a>
                        </div>
                    </div>
            
                    <div class="seguridad">
                        <p class="title-footer">Seguridad</p>
                        <div>
                            <a id="TermCondiciones" href="">Términos y condiciones</a>
                            <a href="">Política de privacidad</a>
                        </div>
                    </div>                        
                </div>
                <div class="footer-box footer-box-icons">
                    <div>
                        <p class="title-footer">Contactanos</p>
                        <div class="icons-social-network">
                            <a href="hello@solventa.com"><img src="assets/img/mail.png" alt="mail icon"></a>
                            <a href="">
                                <img src="assets/img/whastapp.png" alt="whastapp icon">
                            </a>
                            <a href="">
                                <img src="assets/img/telefono.png" alt="phone icon">
                            </a>
                        </div>
                        <p class="title-footer">Seguinos en nuestras redes</p>
                        <div class="icons-social-network">
                            <a href="">
                                <img src="assets/img/facebook.png" alt="facebook icon">
                            </a>
                            <a href="">
                                <img src="assets/img/instagram.png" alt="instagram icon">
                            </a>
                        </div> 
                        <p class="title-footer">Trabajá con nosotros</p>
                        <div class="icons-social-network">
                            <a href="">
                                <img src="assets/img/mail.png" alt="mail icon">
                            </a>
                           
                        </div>                        
                    </div>
                </div>
        </footer>